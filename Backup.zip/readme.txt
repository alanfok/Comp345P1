For A3 , we're using the Design pattern . For the Strategy pattern, we created the Strateguy.cpp and
implement that in the interraction.cpp, and observer is update all the movement the player's doing.
We created the gameStat, gameStatsObserDecorator(with decorator pattern) ,phaseObserver to do it.
All detail is commented in those file. thank you very much.