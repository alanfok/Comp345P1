//
// Created by fok poon kai on 2018-04-01.
//




#ifndef COMP345P1_OBSERVER_H
#define COMP345P1_OBSERVER_H
#include "ListofPlayer.h"
#include <vector>
#include <iostream>

using namespace std;


class Observer{
public:

    void attach(listOfPlayer ls);
    void update_coin();
    void update_conquer();
    void detach(listOfPlayer ls);
    vector <listOfPlayer> phraseObserver;


};







#endif //COMP345P1_OBSERVER_H
