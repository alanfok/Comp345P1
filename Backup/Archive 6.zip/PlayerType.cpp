//
// Created by fok poon kai on 2018-03-31.
//

#include "PlayerType.h"
//Aggressive Player  
AggressivePlayer::AggressivePlayer(){}
AggressivePlayer::~AggressivePlayer(){}
void AggressivePlayer::pickupRaceNSp(Player *x){
//do something};
}
void AggressivePlayer::Conquers(Player *x) {
    //do something
}
void AggressivePlayer::Scores(Player *x) {
    //do something
}

//Defense Player 
DefensePlayer::DefensePlayer() {} 
DefensePlayer::~DefensePlayer() {} 
void DefensePlayer::pickupRaceNSp(Player *x){
//do something};
}
void DefensePlayer::Conquers(Player *x) {
    //do something
}
void DefensePlayer::Scores(Player *x) {
    //do something
}
//ModeratePlayer
ModeratePlayer::ModeratePlayer() {}
ModeratePlayer::~ModeratePlayer() {}
void ModeratePlayer::pickupRaceNSp(Player *x){
//do something};
}
void ModeratePlayer::Conquers(Player *x) {
    //do something
}
void ModeratePlayer::Scores(Player *x) {
    //do something
}
//humanPlayer
HumanPlayer::HumanPlayer() {}
HumanPlayer::~HumanPlayer() {}
void HumanPlayer::pickupRaceNSp(Player *x){
//do something};
}
void HumanPlayer::Conquers(Player *x) {
    //do something
}
void HumanPlayer::Scores(Player *x) {
    //do something
}
//RandomPlayer
RandomPlayer::RandomPlayer() {} 
RandomPlayer::~RandomPlayer() {} 
void RandomPlayer::pickupRaceNSp(Player *x){
//do something};
}
void RandomPlayer::Conquers(Player *x) {
    //do something
}
void RandomPlayer::Scores(Player *x) {
    //do something
}