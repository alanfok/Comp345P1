//
// Created by fok poon kai on 2018-04-03.
//

#ifndef COMP345P1_GAMESTATSOBSERVER_H
#define COMP345P1_GAMESTATSOBSERVER_H

#include "Player.h"
#include <vector>

class gameStatsObserver {
public:
    /*virtual void regions_lost(vector <int> lostRegions, int nbplayers )  = 0;
    virtual void update_region_control(vector <int> playercounter,int nbplayers) = 0;
    virtual void regions_owned(vector <int> playercounter,int nbplayers, Player player) = 0;
    virtual void player_cards(int population_number , int nbplayers , vector <listOfPlayer> vplayer)=0;*/
    // I tried implementing the virtuals but it was not working

};

#endif //COMP345P1_GAMESTATSOBSERVER_H
