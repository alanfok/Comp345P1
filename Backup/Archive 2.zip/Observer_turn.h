//
// Created by fok poon kai on 2018-03-27.
//

#ifndef COMP345P1_OBSERVER_TURN_H
#define COMP345P1_OBSERVER_TURN_H

#include "Player.h"
class Observer_turn{
    Player py;
public:
    ~Observer_turn();
    virtual void Update();

protected:
    Observer_turn();

};
#endif //COMP345P1_OBSERVER_TURN_H
