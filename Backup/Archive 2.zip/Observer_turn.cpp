//
// Created by fok poon kai on 2018-03-27.
//

#include "Observer_turn.h"

Observer_turn::Observer_turn() {};
Observer_turn::~Observer_turn() {};