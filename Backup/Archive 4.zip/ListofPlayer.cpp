//
// Created by fok poon kai on 2018-03-09.
//
#include "ListofPlayer.h"

listOfPlayer::listOfPlayer()
{
    idPlayer = 0;
    victoryCoins = 0;
    population =0 ;
    specialPower = "";
    race = "";
    decline=false;

}

listOfPlayer::listOfPlayer(int idPlayer,int victoryCoins,int population,
                       string specialPower,string race,bool decline)
{
    this->idPlayer = idPlayer;
    this->victoryCoins = victoryCoins;
    this->population =population ;
    this->specialPower = specialPower;
    this->race = race;
    this->decline=decline;
}

int listOfPlayer::getidPlayer()
{
    return idPlayer;

}

int listOfPlayer::getvictoryCoins(){

    return victoryCoins;
}


int listOfPlayer::getpopulation(){

    return population;
}

string listOfPlayer::getspecialPower(){

    return specialPower;
}
string listOfPlayer::getrace(){

    return race;
}
//string NodePlayer::getpointedears(){
//
//    return degreeofpointy;
//}//claudia


void listOfPlayer::setidPlayer(int idPlayer)
{
    this->idPlayer=idPlayer;

}

void listOfPlayer::setvictoryCoins(int victoryCoins){

    this->victoryCoins=victoryCoins;
}


void listOfPlayer::setpopulation(int population){

    this->population=population;
}

void listOfPlayer::setspecialpower( string specialPower){

    this->specialPower= specialPower;
}
void  listOfPlayer::setrace( string race){

    this->race=race;
}


listOfPlayer::~listOfPlayer(){}

bool listOfPlayer::isDecline() const {
    return decline;
}

void listOfPlayer::setDecline(bool decline) {
    listOfPlayer::decline = decline;
};

void listOfPlayer::attach  (Observer &ob) const{
        //push an observer to the list
        views->push_front(&ob);
}

void listOfPlayer::detach(Observer & ob)const{
    bool found = false;
    std::list<Observer*>::iterator findIter = views->begin();

    //go through the list of all the observers looking for the given one
    do{
        if (*findIter == &ob){found = true;}
    }while(findIter++ != views->end() && found == false);

    //if the given observer is found, remove it from the list
    if(found){
        views->erase(findIter);
    }
}

void listOfPlayer::notify_coin()const{
    std::list<Observer *>::iterator i = views->begin();

    //go through the list of all attached observers and notify them
    for (; i != views->end(); ++i){
        (*i)->update_coin();
    }
}

void listOfPlayer::notify_conqeur()const{
    std::list<Observer *>::iterator i = views->begin();

    //go through the list of all attached observers and notify them
    for (; i != views->end(); ++i){
        (*i)->update_conquer();
    }
}