//
// Created by fok poon kai on 2018-03-31.
//

#include "TextDisplayer.h"
//TextDisplayer::TextDisplayer(listOfPlayer &lp) {
//    ptr=&lp;
//    ptr->attach(*this);
//}
//
//void TextDisplayer::update_coin() {
//    inform_coin(ptr->getidPlayer());
//}
//void TextDisplayer::inform_coin(int nbplayid) {
//    cout<<"Player "<<nbplayid<<" collecting coin"<<endl;
//}
//void TextDisplayer::update_conquer()  {
//    inform_conquer(ptr->getidPlayer());
//}
//void TextDisplayer::inform_conquer(int nbplayid){
//    cout<<"Player "<<nbplayid<<" conquer some regions"<<endl;
//}