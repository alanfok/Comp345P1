//
// Created by fok poon kai on 2018-03-31.
//

#include "Strategy.h"
//Aggressive Player  
AggressivePlayer::AggressivePlayer(){}
AggressivePlayer::~AggressivePlayer(){}
void AggressivePlayer::pickupRaceNSp(Player py){
    cout<<"you pick up the Aggressive Player"<<endl;
    cout<<py.vplayer[py.tempNbIndex].getidPlayer()<<endl;
}
void AggressivePlayer::firstEdge(Player py) {
    py.prints();
    maploadernb=py.maploader.nbline;
    playerid=py.vplayer[py.tempNbIndex].getidPlayer();
    playerpop=py.vplayer[py.tempNbIndex].getpopulation();
    do {
        srand(time(NULL));
        randomnum = (rand() + 365) % maploadernb;
        if (py.maploader.adjact[randomnum].compare("y") != 0) {
        Edgeoccupied=false;
        }else{
            if (py.vnodeRegion[randomnum].getregion_status().compare("____water__") == 0 &&
                  py.vplayer[randomnum].getspecialPower().compare("Seafaring") != 0){
                Edgeoccupied=false;
            } else{
               py.population_costv2(playerid,randomnum);
                if(py.temp_populationv2>playerpop){
                    Edgeoccupied=false;
                }else {
                    py.conquers(randomnum,playerid, randomnum, py.temp_populationv2);
                    playerpop -= py.temp_populationv2;
                    py.maploader.losttride[randomnum] = "_none__";
                    Edgeoccupied=true;
                }
            }
        }
    }while (Edgeoccupied==false);

    //do something
}
void AggressivePlayer::Conquers(Player x) {
    //do something
}
void AggressivePlayer::Scores(Player x) {
    //do something
}

//Defense Player 
DefensePlayer::DefensePlayer() {} 
DefensePlayer::~DefensePlayer() {} 
void DefensePlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Defensive Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}


void DefensePlayer::firstEdge(Player py){}


void DefensePlayer::Conquers(Player x) {
    //do something
}
void DefensePlayer::Scores(Player x) {
    //do something
}
//ModeratePlayer
ModeratePlayer::ModeratePlayer() {}
ModeratePlayer::~ModeratePlayer() {}
void ModeratePlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Moderate Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
//do something};
}
void ModeratePlayer::firstEdge(Player py){}

void ModeratePlayer::Conquers(Player x) {
    //do something
}
void ModeratePlayer::Scores(Player x) {
    //do something
}
//humanPlayer
HumanPlayer::HumanPlayer() {}
HumanPlayer::~HumanPlayer() {}
void HumanPlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Human Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}
void HumanPlayer::firstEdge(Player py){}

void HumanPlayer::Conquers(Player x) {
    //do something
}
void HumanPlayer::Scores(Player x) {
    //do something
}
//RandomPlayer
RandomPlayer::RandomPlayer() {} 
RandomPlayer::~RandomPlayer() {} 
void RandomPlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Random Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}
void RandomPlayer::firstEdge(Player py){}

void RandomPlayer::Conquers(Player x) {
    //do something
}
void RandomPlayer::Scores(Player x) {
    //do something
}