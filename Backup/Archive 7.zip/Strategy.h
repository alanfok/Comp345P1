//
// Created by fok poon kai on 2018-03-31.
//

#ifndef COMP345P1_PLAYERTYPE_H
#define COMP345P1_PLAYERTYPE_H
#include <stdio.h>
#include "Player.h"
#include "ListofPlayer.h"
#include <iostream>
using namespace std;


class PlayerType{
public:
    virtual void pickupRaceNSp(Player x) = 0;
    virtual void Conquers(Player x) = 0;
    virtual void  Scores(Player x)  = 0;
    virtual void firstEdge(Player x)=0;
    protected:  
    private: 
};
 class AggressivePlayer: public PlayerType{
public: 
    AggressivePlayer(); 
    ~AggressivePlayer();
    int maploadernb;
    int randomnum;
    int playerid;
    int playerpop;
    bool Edgeoccupied=false;
    void pickupRaceNSp(Player x);
    void Conquers(Player x);
    void Scores(Player x);
    void firstEdge(Player x);

    vector <listOfPlayer> aggoplayer;






};


class DefensePlayer:public PlayerType{
public: 
    DefensePlayer(); 
    ~DefensePlayer();

    void pickupRaceNSp(Player x);
    void Conquers(Player x);
    void Scores(Player x);
    void firstEdge(Player x);
};

class ModeratePlayer:public PlayerType{
public: 
    ModeratePlayer();
    ~ModeratePlayer();
    void pickupRaceNSp(Player x);
    void Conquers(Player x);
    void Scores(Player x);
    void firstEdge(Player x);

};

class HumanPlayer:public PlayerType{
public: 
    HumanPlayer(); 
    ~HumanPlayer();
    void pickupRaceNSp(Player x);
    void Conquers(Player x);
    void Scores(Player x);
    void firstEdge(Player x);
};
class RandomPlayer:public PlayerType{
public:
    RandomPlayer();
    ~RandomPlayer();
    void pickupRaceNSp(Player x);
    void Conquers(Player x);
    void Scores(Player x);
    void firstEdge(Player x);
};
#endif //COMP345P1_PLAYERTYPE_H
