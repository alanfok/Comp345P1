//
// Created by fok poon kai on 2018-04-01.
//

#include "Observer.h"
void Observer::attach(listOfPlayer ls) {
    phraseObserver.push_back(ls);
}

void Observer::update_coin() {
    for (int i = 0; i < phraseObserver.size(); ++i) {
        cout<<"Player "<<phraseObserver[i].getidPlayer()
            <<" collect some coins"<<endl;
    }
}


void Observer::update_conquer() {
    for (int i = 0; i < phraseObserver.size(); ++i) {
        cout<<"Player "<<phraseObserver[i].getidPlayer()
            <<" conquer some regions"<<endl;
    }
}


void Observer::detach(listOfPlayer ls) {
    for (int i = 0; i <phraseObserver.size(); ++i) {
        if(ls.getidPlayer()==phraseObserver[i].getidPlayer()){
            phraseObserver.erase(phraseObserver.begin()+i);
        }
    }
}