//
// Created by fok poon kai on 2018-03-31.
//

#ifndef COMP345P1_OBSERVABLE_H
#define COMP345P1_OBSERVABLE_H
#include "observer.h"
class Observable{

public:
    virtual void attach(Observer & ob)const =0;
    virtual void detach(Observer & ob) const =0;
    virtual void notify() const =0;
};
#endif //COMP345P1_OBSERVABLE_H
