//
// Created by fok poon kai on 2018-03-31.
//

#ifndef COMP345P1_TEXTDESIGN_H
#define COMP345P1_TEXTDESIGN_H
#include "observer.h"
#include "ListofPlayer.h"
#include <sstream>
#include "iostream"
using namespace std;

class listOfPlayer; //forward declaration

class TextDisplayer : public Observer{
public:
    TextDisplayer(listOfPlayer & lp);
    ~TextDisplayer();
    void update_coin();
    void inform_coin(int nbplayid);
    void update_conquer();
    void inform_conquer(int nbplayid);

private:
    listOfPlayer * ptr;
};

#endif //COMP345P1_TEXTDESIGN_H
