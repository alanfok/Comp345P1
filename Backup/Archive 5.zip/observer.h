//
// Created by fok poon kai on 2018-03-31.
//

#ifndef COMP345P1_OBSERVER_H
#define COMP345P1_OBSERVER_H
class Observer{
public:
    virtual void update_coin()  const =0;
    virtual void update_conquer() const=0;
};
#endif //COMP345P1_OBSERVER_H
