//
// Created by fok poon kai on 2018-03-31.
//

#ifndef COMP345P1_PLAYERTYPE_H
#define COMP345P1_PLAYERTYPE_H
#include <stdio.h>
#include "Player.h"
#include "ListofPlayer.h"
#include <iostream>
#include "Observer.h"





using namespace std;


class PlayerType{
public:
    virtual void pickupRaceNSp(Player x) = 0;
    virtual void conquers(Player x) = 0;
    virtual void  scores(Player x)  = 0;
    virtual void firstEdge(Player x)=0;
    virtual void redeployment(Player x)=0;

    protected:  
    private: 
};
 class AggressivePlayer: public PlayerType{
public: 
    AggressivePlayer(); 
    ~AggressivePlayer();
    Observer observer;
    int total_number_of_region;
    int randomnumber;
    int playerid;
    int playerpop;
    int temp_region;
    bool conquer_check;
    bool Edgeoccupied;
    void pickupRaceNSp(Player x);
    void conquers(Player x);
    void scores(Player x);
    void firstEdge(Player x);
    void redeployment(Player x);

};


class DefensivePlayer:public PlayerType{
public: 
    DefensivePlayer(); 
    ~DefensivePlayer();
    Observer observer;
    void pickupRaceNSp(Player x);
    void conquers(Player x);
    void scores(Player x);
    void firstEdge(Player x);
    void redeployment(Player x);
};

class ModeratePlayer:public PlayerType{
public: 
    ModeratePlayer();
    ~ModeratePlayer();
    Observer observer;
    void pickupRaceNSp(Player x);
    void conquers(Player x);
    void scores(Player x);
    void firstEdge(Player x);
    void redeployment(Player x);

};

class HumanPlayer:public PlayerType{
public: 
    HumanPlayer(); 
    ~HumanPlayer();
    void pickupRaceNSp(Player x);
    void conquers(Player x);
    void scores(Player x);
    void firstEdge(Player x);
    void redeployment(Player x);
};
class RandomPlayer:public PlayerType{
public:
    RandomPlayer();
    ~RandomPlayer();
    Observer observer;
    void pickupRaceNSp(Player x);
    void conquers(Player x);
    void scores(Player x);
    void firstEdge(Player x);
    void redeployment(Player x);
};
#endif //COMP345P1_PLAYERTYPE_H
