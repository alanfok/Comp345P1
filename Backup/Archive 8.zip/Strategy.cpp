//
// Created by fok poon kai on 2018-03-31.
//

#include "Strategy.h"
//Aggressive Player  
AggressivePlayer::AggressivePlayer(){}
AggressivePlayer::~AggressivePlayer(){}
void AggressivePlayer::pickupRaceNSp(Player py){
    cout<<"you pick up the Aggressive Player"<<endl;
    cout<<py.vplayer[py.tempNbIndex].getidPlayer()<<endl;
}
void AggressivePlayer::firstEdge(Player py) {
    observer.attach(py.vplayer[py.tempNbIndex]);
    observer.update_conquer();
    py.prints();
    total_number_of_region=py.maploader.nbline;
    playerid=py.vplayer[py.tempNbIndex].getidPlayer();
    playerpop=py.vplayer[py.tempNbIndex].getpopulation();
    do {
        srand(time(NULL));
        randomnumber = (rand() + 365) % total_number_of_region;
        if (py.maploader.adjact[randomnumber].compare("y") != 0) {
        Edgeoccupied=false;
        }else{
            if (py.vnodeRegion[randomnumber].getregion_status().compare("____water__") == 0 &&
                  py.vplayer[randomnumber].getspecialPower().compare("Seafaring") != 0){
                Edgeoccupied=false;
            } else{
               py.population_costv2(playerid,randomnumber);
                if(py.cost_of_population>playerpop){
                    Edgeoccupied=false;
                }else {
                    py.conquers(randomnumber,playerid, randomnumber, py.cost_of_population);
                    playerpop -= py.cost_of_population;
                    py.maploader.losttride[randomnumber] = "_none__";
                    Edgeoccupied=true;
                }
            }
        }
    }while (Edgeoccupied==false);
    py.prints();
}
void AggressivePlayer::conquers(Player py) {
    observer.update_conquer();
    playerid=py.vplayer[py.tempNbIndex].getidPlayer();
    playerpop=py.vplayer[py.tempNbIndex].getpopulation();
    for (int i = 0; i < py.vnodeRegion.size(); ++i) {
        if(py.vnodeRegion[i].getid_player()==playerid){
            temp_region=i;
            break;
        }
    }
    conquer_check=false;
    do {  if(py.vplayer[py.tempNbIndex].getpopulation()<=0){
            conquer_check=true;
            }
        else{
            for (int j = 0; j < py.vnodeRegion.size(); ++j) {
                if (py.maploader.maps.pt[j][temp_region] == 1 && (j != temp_region)&&
                        py.vnodeRegion[j].getid_player()!=playerid) {
                    py.population_costv2(playerid,j);

                    if(py.cost_of_population<playerpop){
                        py.invade_v2(playerid, j);
                        py.conquers_v2(j, playerid, py.cost_of_population);
                        playerpop -= py.cost_of_population;//reduce the population
                    }else{
                        cout<<playerid<<" throw dice"<<endl;
                        int dicenb=py.getthrowdie();
                        cout<<dicenb<<endl;
                        if((dicenb+playerpop)>py.cost_of_population){
                            py.invade_v2(playerid, j);
                            py.conquers_v2(j, playerid, py.cost_of_population);
                            playerpop -= playerpop;
                            conquer_check=true;
                        }
                    }
                }
            }
        }
    }while(!conquer_check);
}





void AggressivePlayer::redeployment(Player py){
   py.AI_redeployment();
};
void AggressivePlayer::scores(Player x) {
    //do something
}

//Defense Player 
DefensivePlayer::DefensivePlayer() {} 
DefensivePlayer::~DefensivePlayer() {} 
void DefensivePlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Defensive Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}


void DefensivePlayer::firstEdge(Player py){}


void DefensivePlayer::conquers(Player x) {
    //do something
}
void DefensivePlayer::redeployment(Player x){};
void DefensivePlayer::scores(Player x) {
    //do something
}
//ModeratePlayer
ModeratePlayer::ModeratePlayer() {}
ModeratePlayer::~ModeratePlayer() {}
void ModeratePlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Moderate Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
//do something};
}
void ModeratePlayer::firstEdge(Player py){}

void ModeratePlayer::conquers(Player x) {
    //do something
}
void ModeratePlayer::redeployment(Player x){};
void ModeratePlayer::scores(Player x) {
    //do something
}
//humanPlayer
HumanPlayer::HumanPlayer() {}
HumanPlayer::~HumanPlayer() {}
void HumanPlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Human Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}
void HumanPlayer::firstEdge(Player py){}

void HumanPlayer::conquers(Player x) {
    //do something
}
void HumanPlayer::redeployment(Player x){};
void HumanPlayer::scores(Player x) {
    //do something
}
//RandomPlayer
RandomPlayer::RandomPlayer() {} 
RandomPlayer::~RandomPlayer() {} 
void RandomPlayer::pickupRaceNSp(Player x){
    cout<<"you pick up the Random Player"<<endl;
    cout<<x.vplayer[x.tempNbIndex].getidPlayer()<<endl;
}
void RandomPlayer::firstEdge(Player py){}

void RandomPlayer::conquers(Player x) {
    //do something
}
void RandomPlayer::redeployment(Player x){};
void RandomPlayer::scores(Player x) {
    //do something
}