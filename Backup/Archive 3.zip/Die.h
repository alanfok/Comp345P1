//
// Created by fok poon kai on 2018-02-03.
//

#ifndef COMP345P1_DIE_H
#define COMP345P1_DIE_H
#include <iostream>
#include <stdlib.h>
#include <time.h>
using   namespace std;

class Die {
public:
    int dice1 ;
    int throwsOne();

};


#endif //COMP345P1_DIE_H
